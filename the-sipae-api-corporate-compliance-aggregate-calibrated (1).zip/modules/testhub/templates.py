TEST_HUB_HTML = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIPAE API Hub - Panel de Pruebas</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { --bg: #1e1e2f; --panel: #2a2a40; --text: #e0e0e0; --accent: #ff4757; --accent-hover: #ff6b81; --success: #2ecc71; --warning: #f1c40f; --info: #3498db; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: var(--bg); color: var(--text); margin: 0; padding: 20px; }
        h1 { text-align: center; color: #fff; margin-bottom: 5px; }
        p.subtitle { text-align: center; color: #a0a0b0; margin-top: 0; margin-bottom: 30px; }
        
        .controls { background: var(--panel); padding: 20px; border-radius: 8px; display: flex; flex-wrap: wrap; gap: 15px; justify-content: center; align-items: flex-end; box-shadow: 0 4px 6px rgba(0,0,0,0.3); margin-bottom: 30px; }
        .controls label { font-weight: bold; font-size: 14px; color: #bbb; display: block; margin-bottom: 5px;}
        .controls select, .controls input { background: #1e1e2f; color: #fff; border: 1px solid #444; padding: 8px 12px; border-radius: 4px; outline: none; }
        .controls button { background: var(--accent); color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: bold; transition: 0.3s; height: 38px;}
        .controls button:hover { background: var(--accent-hover); }

        /* Grid System */
        .dashboard-grid { display: grid; grid-template-columns: 1fr 2fr; gap: 20px; max-width: 1300px; margin: 0 auto; display: none; }
        .card { background: var(--panel); padding: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.3); overflow: hidden; }
        .card h3 { margin-top: 0; border-bottom: 1px solid #444; padding-bottom: 10px; color: #fff; }
        
        /* Text & Status */
        .kpi-row { display: flex; justify-content: space-around; flex-wrap: wrap; margin-bottom: 15px; }
        .kpi-box { text-align: center; background: #1e1e2f; padding: 15px; border-radius: 6px; min-width: 120px; border: 1px solid #333; }
        .kpi-box .val { font-size: 26px; font-weight: bold; color: var(--info); }
        .kpi-box .lbl { font-size: 12px; color: #aaa; text-transform: uppercase; margin-top: 5px; }
        
        .status-indicator { text-align: center; padding: 15px; border-radius: 8px; margin-bottom: 15px; font-size: 18px; font-weight: bold; border: 2px solid transparent; }
        .status-complete { background: rgba(46, 204, 113, 0.1); border-color: var(--success); color: var(--success); }
        .status-missing { background: rgba(231, 76, 60, 0.1); border-color: var(--accent); color: var(--accent); }

        /* Banner Metadata */
        .meta-banner { display: none; justify-content: space-between; align-items: center; background: rgba(52, 152, 219, 0.1); padding: 12px 20px; border-radius: 8px; margin: 0 auto 20px auto; border-left: 4px solid var(--info); max-width: 1300px;}
        .btn-refresh { background: rgba(255, 255, 255, 0.05); border: 1px solid #444; color: #fff; padding: 6px 15px; border-radius: 6px; cursor: pointer; font-weight: bold; transition: 0.2s; display: flex; align-items: center; gap: 8px; font-size: 13px;}
        .btn-refresh:hover:not(:disabled) { background: rgba(255, 255, 255, 0.1); border-color: #666; }
        .btn-refresh:disabled { opacity: 0.5; cursor: not-allowed; }

        /* Tags */
        .tag-container { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; margin-top: 15px; }
        .tag { background: rgba(255,255,255,0.1); padding: 5px 12px; border-radius: 20px; font-size: 13px; font-weight: bold; border: 1px solid #555; display: inline-block;}
        .tag.tag-red { border-color: var(--accent); color: var(--accent); background: rgba(255, 71, 87, 0.1); }
        .tag.tag-warn { border-color: var(--warning); color: var(--warning); background: rgba(241, 196, 15, 0.1); }
        .tag.tag-green { border-color: var(--success); color: var(--success); background: rgba(46, 204, 113, 0.1); }

        /* Tables */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 14px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #444; }
        th { background-color: #1e1e2f; color: #bbb; position: sticky; top: 0; }
        tr:hover { background-color: rgba(255,255,255,0.05); }
        .table-container { max-height: 350px; overflow-y: auto; margin-bottom: 15px; }

        /* Code Area */
        #rawJson { background: #1e1e2f; padding: 15px; border-radius: 5px; font-family: monospace; color: #a8ff60; overflow-x: auto; max-height: 300px; }
        
        /* Context Views */
        .view-layer { display: none; }
        .view-layer.active { display: contents; }
        .full-col { grid-column: 1 / -1; }
        
        /* Chart Wrappers */
        .chart-container-relative { position: relative; height: 300px; width: 100%; }
        
        /* Flex Helpers */
        .flex-container { display: flex; gap: 15px; }
    </style>
</head>
<body>

    <h1>🐺 SIPAE API Hub</h1>
    <p class="subtitle">Panel Central de Microservicios Operativos (Default: Solo Hoy)</p>

    <div class="controls">
        <div>
            <label>Servicio API:</label>
            <select id="apiSelector" onchange="handleApiChange()">
                <option value="attendance-detail">Alumnos - Análisis Detallado (Asistencia)</option>
                <option value="husky">Alumnos - Husky Pass Tasa de Captura</option>
                <option value="retardos">Alumnos - Husky Pass Retardos (Plantel)</option>
                <option value="emp-kardex">Empleados - Asistencia y Retardos (Kardex)</option>
                <option value="sapf-monthly">SAPF - Fichas de Atención (Mensual por Área)</option>
                <option value="sapf-motivos">SAPF - Fichas de Atención (Motivos)</option>
                <option value="academic-obs">Académico - Observaciones de Clase</option>
                <option value="academic-plan">Académico - Planeaciones</option>
            </select>
        </div>

        <div id="plantelContainer">
            <label>Plantel:</label>
            <select id="plantel">
                <option value="PT">Primaria Toluca (PT)</option>
                <option value="PM">Primaria Metepec (PM)</option>
                <option value="ST">Secundaria Toluca (ST)</option>
                <option value="SM">Secundaria Metepec (SM)</option>
                <option value="PREET">Preescolar Toluca (PREET)</option>
                <option value="PREEM">Preescolar Metepec (PREEM)</option>
            </select>
        </div>

        <div>
            <label>Alcance (Scope):</label>
            <select id="scopeSelector" onchange="handleScopeChange()">
                <option value="today">Hoy (Caché Optimizado)</option>
                <option value="range">Rango Personalizado</option>
                <option value="month">Este Mes</option>
                <option value="ciclo_escolar">Ciclo Escolar Actual</option>
            </select>
        </div>

        <div id="dateInputs" class="flex-container" style="display: none;">
            <div>
                <label>Desde:</label>
                <input type="date" id="startDate">
            </div>
            <div>
                <label>Hasta:</label>
                <input type="date" id="endDate">
            </div>
        </div>

        <button onclick="fetchData(false)">⚡ Ejecutar Consulta</button>
    </div>

    <!-- SWR Meta Indicator Banner -->
    <div id="metaBanner" class="meta-banner">
        <div style="display:flex; align-items:center; gap: 15px;">
            <span id="metaTimeText" style="font-size: 14px; font-weight: 500; color: #fff;"></span>
            <span id="metaBadge" class="tag"></span>
        </div>
        <button id="btnForceRefresh" class="btn-refresh" onclick="fetchData(true)">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2v6h-6"></path><path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path><path d="M3 22v-6h6"></path><path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path></svg> 
            Sincronizar Manualmente
        </button>
    </div>

    <div class="dashboard-grid" id="mainDashboard">
        
        <!-- HUSKY PASS VIEW -->
        <div id="viewHusky" class="view-layer">
            <div class="card">
                <h3>📊 Tasa de Captura (Medidor)</h3>
                <canvas id="gaugeChart"></canvas>
                <div style="text-align:center; margin-top:15px;" id="gaugeStats"></div>
            </div>
            <div class="card">
                <h3>📈 Tendencia Diaria (Entradas vs Salidas)</h3>
                <div class="chart-container-relative">
                    <canvas id="barChart"></canvas>
                </div>
            </div>
        </div>

        <!-- ATTENDANCE VIEW -->
        <div id="viewAttendance" class="view-layer">
            <div class="card full-col" id="attRangeWrapper" style="display:none;">
                <h3>📅 Tendencia Histórica</h3>
                <div class="chart-container-relative" style="height: 250px;">
                    <canvas id="attendanceRangeChart"></canvas>
                </div>
                <div style="margin-top: 20px; background: #1e1e2f; padding: 15px; border-radius: 6px; text-align: center;">
                    <label style="font-weight:bold; margin-right:10px;">Inspeccionar día específico:</label>
                    <select id="daySelector" onchange="renderSpecificDay()"></select>
                </div>
            </div>

            <div class="card" id="attStatusCard" style="display:none;">
                <h3 id="attDayTitle">📋 Cobertura y KPIs del Día</h3>
                <div id="attendanceStatus" class="status-indicator"></div>
                <div class="kpi-row" id="kpiContainer"></div>
                <div id="missingGroupsContainer" style="display:none; margin-top: 15px; border-top: 1px solid #444; padding-top: 15px;">
                    <p style="text-align: center; color: #bbb; margin-bottom: 10px;">Grupos Faltantes Identificados:</p>
                    <div class="tag-container" id="missingGroupsList"></div>
                </div>
            </div>

            <div class="card" id="attDataCard" style="display:none;">
                <h3>📂 Desglose por Grado y Grupo</h3>
                <div class="table-container">
                    <table id="groupsTable">
                        <thead>
                            <tr>
                                <th>Grupo</th>
                                <th>Total Alumnos</th>
                                <th>Asistencia</th>
                                <th>Ausencia</th>
                                <th>Presencial</th>
                                <th>Virtual</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>

                <h3 style="margin-top: 20px;">⚠️ Listado de Ausencias</h3>
                <div class="table-container">
                    <table id="absentsTable">
                        <thead>
                            <tr>
                                <th>Alumno</th>
                                <th>Grupo</th>
                                <th>Motivo</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- RETARDOS VIEW -->
        <div id="viewRetardos" class="view-layer">
            <div class="card full-col">
                <div style="display:flex; justify-content:space-between; align-items:center; border-bottom: 1px solid #444; padding-bottom: 10px; margin-bottom: 15px;">
                    <h3 style="border:none; margin:0; padding:0;">⏰ Historial de Retardos (Plantel)</h3>
                    <div id="retardosKpi" style="font-size: 20px; font-weight:bold; color:var(--accent);"></div>
                </div>
                <div class="table-container">
                    <table id="retardosTable">
                        <thead>
                            <tr>
                                <th>ID Registro</th>
                                <th>Alumno</th>
                                <th>Matrícula</th>
                                <th>Fecha</th>
                                <th>Hora de Entrada</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- EMPLOYEES KARDEX VIEW -->
        <div id="viewEmployeeKardex" class="view-layer">
            <div class="card full-col">
                <div style="display:flex; justify-content:space-between; align-items:center; border-bottom: 1px solid #444; padding-bottom: 10px; margin-bottom: 15px;">
                    <h3 style="border:none; margin:0; padding:0;">🗂️ KPIs de Plantilla Externa (Kardex)</h3>
                </div>
                <div class="kpi-row" id="kardexKpiContainer"></div>
                
                <div id="kardexDebugContainer" style="display:none; margin-bottom: 20px; padding: 15px; border: 1px solid var(--warning); background: rgba(241, 196, 15, 0.05); border-radius: 6px;">
                    <p style="margin-top:0; font-weight:bold; color: var(--warning);">⚠️ Diagnóstico: Áreas Externas No Mapeadas</p>
                    <p style="font-size: 12px; color: #bbb; margin-bottom: 10px;">Las siguientes áreas fueron detectadas en Kardex pero no están enlazadas a un Plantel normalizado. No afectarán los conteos oficiales, pero deben mapearse en código si es necesario.</p>
                    <div class="tag-container" id="unmappedAreasList" style="justify-content: flex-start;"></div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div>
                        <h4 style="color:var(--warning); margin-bottom: 10px;">⏱️ Empleados con Retardos</h4>
                        <div class="table-container">
                            <table id="empRetardosTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nombre</th>
                                        <th>Fecha</th>
                                        <th>Estatus Kardex</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div>
                        <h4 style="color:var(--accent); margin-bottom: 10px;">🚫 Empleados con Ausencias</h4>
                        <div class="table-container">
                            <table id="empAusenciasTable">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Nombre</th>
                                        <th>Fecha</th>
                                        <th>Estatus Kardex</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- SAPF MONTHLY VIEW -->
        <div id="viewSapfMonthly" class="view-layer">
            <div class="card full-col">
                <h3>📂 Tendencia Mensual por Área (SAPF)</h3>
                <div id="sapfAreasContainer" style="display:flex; flex-direction:column; gap:20px;"></div>
            </div>
        </div>

        <!-- SAPF MOTIVOS VIEW -->
        <div id="viewSapfMotivos" class="view-layer">
            <div class="card full-col">
                <h3>⚠️ Incidencias por Motivo (SAPF)</h3>
                <div class="table-container">
                    <table id="sapfMotivosTable">
                        <thead>
                            <tr>
                                <th>Área</th>
                                <th>Motivo</th>
                                <th>Conteo</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ACADEMIC OBSERVACIONES VIEW -->
        <div id="viewAcademicObs" class="view-layer">
            <div class="card">
                <h3>📈 Tendencia de Observaciones de Clase</h3>
                <div class="kpi-row" id="obsKpiContainer"></div>
                <div class="chart-container-relative">
                    <canvas id="obsBarChart"></canvas>
                </div>
            </div>
            <div class="card">
                <h3>🗣️ Retroalimentación de Estrategias</h3>
                <div class="table-container" style="max-height: 400px;">
                    <table id="obsCommentsTable">
                        <thead>
                            <tr>
                                <th>Docente</th>
                                <th>Fecha</th>
                                <th>Comentario / Estrategia</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ACADEMIC PLANEACIONES VIEW -->
        <div id="viewAcademicPlan" class="view-layer">
            <div class="card">
                <h3>📈 Tendencia de Planeaciones Entregadas</h3>
                <div class="kpi-row" id="planKpiContainer"></div>
                <div class="chart-container-relative">
                    <canvas id="planBarChart"></canvas>
                </div>
            </div>
            <div class="card">
                <h3>📝 Feedback Coordinación</h3>
                <div class="table-container" style="max-height: 400px;">
                    <table id="planCommentsTable">
                        <thead>
                            <tr>
                                <th>Docente</th>
                                <th>Fecha</th>
                                <th>Retroalimentación</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- RAW JSON LOG -->
        <div class="card full-col">
            <h3>⚙️ Carga de Datos en Crudo (JSON)</h3>
            <pre id="rawJson"></pre>
        </div>

    </div>

    <script>
        document.getElementById('startDate').valueAsDate = new Date();
        document.getElementById('endDate').valueAsDate = new Date();

        let charts = { gauge: null, bar: null, attRange: null, obsBar: null, planBar: null };
        let currentGlobalData = null; 

        function handleScopeChange() {
            const scope = document.getElementById('scopeSelector').value;
            const dateInputs = document.getElementById('dateInputs');
            if (scope === 'range') {
                dateInputs.style.display = 'flex';
            } else {
                dateInputs.style.display = 'none';
            }
        }

        function handleApiChange() {
            document.getElementById('plantelContainer').style.display = 'block';
            clearDashboards();
            document.getElementById('metaBanner').style.display = 'none';
        }

        function clearDashboards() {
            document.getElementById('mainDashboard').style.display = 'none';
            if(charts.gauge) charts.gauge.destroy();
            if(charts.bar) charts.bar.destroy();
            if(charts.attRange) charts.attRange.destroy();
            if(charts.obsBar) charts.obsBar.destroy();
            if(charts.planBar) charts.planBar.destroy();
        }

        async function fetchData(forceRefresh = false) {
            const api = document.getElementById('apiSelector').value;
            const scope = document.getElementById('scopeSelector').value;
            const plantel = document.getElementById('plantel').value;
            const start = document.getElementById('startDate').value;
            const end = document.getElementById('endDate').value;
            
            let url = '';
            
            if (api === 'husky') {
                url = `/api/v1/husky/scans/daily-rate?plantel=${plantel}&scope=${scope}`;
            } else if (api === 'attendance-detail') {
                url = `/api/v1/attendance/detail?plantel=${plantel}&scope=${scope}`;
            } else if (api === 'retardos') {
                url = `/api/v1/husky/retardos?plantel=${plantel}&scope=${scope}`;
            } else if (api === 'emp-kardex') {
                url = `/api/v1/employee-attendance/kardex-report?plantel=${plantel}&scope=${scope}`;
            } else if (api === 'sapf-monthly') {
                url = `/api/v1/sapf/monthly-summary?plantel=${plantel}&scope=${scope}`;
            } else if (api === 'sapf-motivos') {
                url = `/api/v1/sapf/motivos-summary?plantel=${plantel}&scope=${scope}`;
            } else if (api === 'academic-obs') {
                url = `/api/v1/academic/observaciones?plantel=${plantel}&scope=${scope}`;
            } else if (api === 'academic-plan') {
                url = `/api/v1/academic/planeaciones?plantel=${plantel}&scope=${scope}`;
            }

            if (scope === 'range') {
                url += `&start_date=${start}&end_date=${end}`;
            }
            if (forceRefresh) {
                url += `&force_refresh=true`;
            }
            
            const btnRefresh = document.getElementById('btnForceRefresh');
            if (forceRefresh) {
                btnRefresh.innerHTML = '⏳ Procesando Sincronización...';
                btnRefresh.disabled = true;
            }

            try {
                const response = await fetch(url);
                const data = await response.json();
                currentGlobalData = data;
                
                // Manejo del bloque Metadata (SWR Caching)
                const metaBanner = document.getElementById('metaBanner');
                if (data.meta) {
                    metaBanner.style.display = 'flex';
                    const d = new Date(data.meta.cached_at);
                    const timeString = d.toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
                    
                    document.getElementById('metaTimeText').innerText = `Información al corte de las ${timeString} hrs`;
                    
                    const badge = document.getElementById('metaBadge');
                    if (data.meta.is_cached) {
                        badge.className = 'tag tag-warn';
                        badge.innerText = '⚡ Modo Optimizado (Caché)';
                    } else {
                        badge.className = 'tag tag-green';
                        badge.innerText = '🟢 Sincronizado en Vivo';
                    }
                } else {
                    metaBanner.style.display = 'none';
                }

                document.getElementById('mainDashboard').style.display = 'grid';
                document.getElementById('rawJson').innerText = JSON.stringify(data, null, 2);

                document.querySelectorAll('.view-layer').forEach(el => el.classList.remove('active'));
                
                if (api === 'husky') {
                    document.getElementById('viewHusky').classList.add('active');
                    renderHusky(data);
                } else if (api === 'attendance-detail') {
                    document.getElementById('viewAttendance').classList.add('active');
                    renderAttendance(data);
                } else if (api === 'retardos') {
                    document.getElementById('viewRetardos').classList.add('active');
                    renderRetardos(data);
                } else if (api === 'emp-kardex') {
                    document.getElementById('viewEmployeeKardex').classList.add('active');
                    renderEmployeeKardex(data);
                } else if (api === 'sapf-monthly') {
                    document.getElementById('viewSapfMonthly').classList.add('active');
                    renderSapfMonthly(data);
                } else if (api === 'sapf-motivos') {
                    document.getElementById('viewSapfMotivos').classList.add('active');
                    renderSapfMotivos(data);
                } else if (api === 'academic-obs') {
                    document.getElementById('viewAcademicObs').classList.add('active');
                    renderAcademicObs(data);
                } else if (api === 'academic-plan') {
                    document.getElementById('viewAcademicPlan').classList.add('active');
                    renderAcademicPlan(data);
                }
            } catch (error) {
                alert('Error crítico de conexión o servidor. Revisa la consola.');
                console.error(error);
            } finally {
                if (forceRefresh) {
                    btnRefresh.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 2v6h-6"></path><path d="M3 12a9 9 0 0 1 15-6.7L21 8"></path><path d="M3 22v-6h6"></path><path d="M21 12a9 9 0 0 1-15 6.7L3 16"></path></svg> Sincronizar Manualmente';
                    btnRefresh.disabled = false;
                }
            }
        }

        function renderHusky(data) {
            const pop = data.expected_population;
            const dates = Object.keys(data.daily_datapoints);
            let totalEntradas = 0, entradasArr = [], salidasArr = [];

            dates.forEach(date => {
                const dayData = data.daily_datapoints[date];
                totalEntradas += dayData.entrada;
                entradasArr.push(dayData.entrada);
                salidasArr.push(dayData.salida);
            });

            const capturedAvg = dates.length > 0 ? Math.round(totalEntradas / dates.length) : 0;
            const missingAvg = pop > capturedAvg ? pop - capturedAvg : 0;
            const percent = pop > 0 ? Math.round((capturedAvg / pop) * 100) : 0;

            const ctxGauge = document.getElementById('gaugeChart').getContext('2d');
            charts.gauge = new Chart(ctxGauge, {
                type: 'doughnut',
                data: {
                    labels: ['Promedio Entradas', 'Faltantes'],
                    datasets: [{ data: [capturedAvg, missingAvg], backgroundColor: ['#2ecc71', '#e74c3c'], borderWidth: 0 }]
                },
                options: { rotation: -90, circumference: 180, cutout: '75%', plugins: { legend: { labels: {color: '#fff'} } } }
            });

            document.getElementById('gaugeStats').innerHTML = `
                <div style="font-size:32px; font-weight:bold; color:var(--accent);">${percent}%</div>
                <div style="color:#aaa; font-size:14px;">del total esperado de ${pop}</div>
            `;

            const ctxBar = document.getElementById('barChart').getContext('2d');
            charts.bar = new Chart(ctxBar, {
                type: 'bar',
                data: {
                    labels: dates,
                    datasets: [
                        { label: 'Entradas', data: entradasArr, backgroundColor: '#3498db' },
                        { label: 'Salidas', data: salidasArr, backgroundColor: '#f1c40f' }
                    ]
                },
                options: { responsive: true, maintainAspectRatio: false, scales: { y: { grid: { color: '#444' }, ticks: { color: '#ccc'} }, x: { grid: { display: false }, ticks: { color: '#ccc'} } }, plugins: { legend: { labels: { color: '#fff' } } } }
            });
        }

        function renderAttendance(data) {
            const isDaily = data.mode === 'daily';
            
            document.getElementById('attRangeWrapper').style.display = isDaily ? 'none' : 'block';
            document.getElementById('attStatusCard').style.display = 'block';
            document.getElementById('attDataCard').style.display = 'block';
            
            if (isDaily) {
                injectDailyDetails(data, data.date_range.start);
            } else {
                const dates = Object.keys(data.daily_points);
                const sel = document.getElementById('daySelector');
                sel.innerHTML = dates.map(d => `<option value="${d}">${d}</option>`).join('');
                
                let assistArr = [], absArr = [];
                dates.forEach(d => {
                    assistArr.push(data.daily_points[d].summary.asistencia);
                    absArr.push(data.daily_points[d].summary.ausencia);
                });

                if(charts.attRange) charts.attRange.destroy();
                const ctxR = document.getElementById('attendanceRangeChart').getContext('2d');
                charts.attRange = new Chart(ctxR, {
                    type: 'line',
                    data: {
                        labels: dates,
                        datasets: [
                            { label: 'Asistencias', data: assistArr, borderColor: '#2ecc71', backgroundColor: 'rgba(46, 204, 113, 0.1)', fill: true, tension: 0.3 },
                            { label: 'Ausencias', data: absArr, borderColor: '#e74c3c', backgroundColor: 'transparent', borderDash: [5,5], tension: 0.3 }
                        ]
                    },
                    options: { responsive: true, maintainAspectRatio: false, scales: { y: { grid: { color: '#444' }, ticks: { color: '#ccc'} }, x: { grid: { display: false }, ticks: { color: '#ccc'} } }, plugins: { legend: { labels: { color: '#fff' } } } }
                });

                if (dates.length > 0) renderSpecificDay();
            }
        }

        function renderSpecificDay() {
            const day = document.getElementById('daySelector').value;
            if(currentGlobalData && currentGlobalData.daily_points[day]) {
                injectDailyDetails(currentGlobalData.daily_points[day], day);
            }
        }

        function injectDailyDetails(dayObj, dateLabel) {
            document.getElementById('attDayTitle').innerText = `📋 Cobertura del ${dateLabel}`;
            
            const statusEl = document.getElementById('attendanceStatus');
            const missingContainer = document.getElementById('missingGroupsContainer');
            const tagsContainer = document.getElementById('missingGroupsList');
            const md = dayObj.missing_groups_data;

            if (md.is_complete) {
                statusEl.className = 'status-indicator status-complete';
                statusEl.innerHTML = `✅ Cobertura Completa (${md.completion_percent}%)`;
                missingContainer.style.display = 'none';
            } else {
                statusEl.className = 'status-indicator status-missing';
                statusEl.innerHTML = `⚠️ Faltan ${md.missing_groups_count} Grupos (${md.completion_percent}%)`;
                missingContainer.style.display = 'block';
                tagsContainer.innerHTML = md.missing_groups.map(g => `<span class="tag tag-red">${g.grado}° ${g.grupo}</span>`).join('');
            }

            const sum = dayObj.summary;
            document.getElementById('kpiContainer').innerHTML = `
                <div class="kpi-box"><div class="val" style="color:var(--text);">${sum.total_students}</div><div class="lbl">Esperados</div></div>
                <div class="kpi-box"><div class="val" style="color:var(--success);">${sum.asistencia}</div><div class="lbl">Asistencias</div></div>
                <div class="kpi-box"><div class="val" style="color:var(--accent);">${sum.ausencia}</div><div class="lbl">Ausencias</div></div>
                <div class="kpi-box"><div class="val" style="color:#f39c12;">${sum.presencial}</div><div class="lbl">Presencial</div></div>
                <div class="kpi-box"><div class="val" style="color:#9b59b6;">${sum.virt}</div><div class="lbl">Virtual</div></div>
            `;

            const gBody = document.querySelector('#groupsTable tbody');
            if (dayObj.groups.length === 0) {
                gBody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:#888;">No hay capturas para esta fecha.</td></tr>`;
            } else {
                gBody.innerHTML = dayObj.groups.map(g => `
                    <tr>
                        <td><b>${g.grado}° ${g.grupo}</b></td>
                        <td>${g.total_students_per_group}</td>
                        <td style="color:var(--success);">${g.asistencia}</td>
                        <td style="color:var(--accent);">${g.ausencia}</td>
                        <td>${g.presencial}</td>
                        <td>${g.virt}</td>
                    </tr>
                `).join('');
            }

            const aBody = document.querySelector('#absentsTable tbody');
            if (dayObj.absent_students.length === 0) {
                aBody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#888;">No se registraron ausencias.</td></tr>`;
            } else {
                aBody.innerHTML = dayObj.absent_students.map(a => `
                    <tr>
                        <td>${a.name}</td>
                        <td><b>${a.grado}° ${a.grupo}</b></td>
                        <td><span class="tag">${a.motivo || 'N/A'}</span></td>
                    </tr>
                `).join('');
            }
        }

        function renderRetardos(data) {
            document.getElementById('retardosKpi').innerText = `Total: ${data.total_retardos} Retardos`;
            const rBody = document.querySelector('#retardosTable tbody');
            
            if (data.retardos.length === 0) {
                rBody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:#888;">No hay retardos registrados en el rango (Scope: ${data.scope}).</td></tr>`;
            } else {
                rBody.innerHTML = data.retardos.map(r => `
                    <tr>
                        <td><span class="tag">${r.id}</span></td>
                        <td><b>${r.student_fullname}</b></td>
                        <td>${r.matricula}</td>
                        <td>${r.date}</td>
                        <td style="color:var(--warning); font-weight:bold;">${r.time}</td>
                    </tr>
                `).join('');
            }
        }

        function renderEmployeeKardex(data) {
            document.getElementById('kardexKpiContainer').innerHTML = `
                <div class="kpi-box"><div class="val" style="color:var(--warning);">${data.summary.retardos_count}</div><div class="lbl">Retardos</div></div>
                <div class="kpi-box"><div class="val" style="color:var(--accent);">${data.summary.ausencias_count}</div><div class="lbl">Ausencias / Faltas</div></div>
            `;

            const dbgContainer = document.getElementById('kardexDebugContainer');
            const unmappedList = document.getElementById('unmappedAreasList');
            if (data.debug.unmapped_areas && data.debug.unmapped_areas.length > 0) {
                dbgContainer.style.display = 'block';
                unmappedList.innerHTML = data.debug.unmapped_areas.map(a => `<span class="tag tag-warn">${a}</span>`).join('');
            } else {
                dbgContainer.style.display = 'none';
            }

            const retBody = document.querySelector('#empRetardosTable tbody');
            if (data.retardos.length === 0) {
                retBody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:#888;">Sin registros.</td></tr>`;
            } else {
                retBody.innerHTML = data.retardos.map(r => `
                    <tr>
                        <td><span class="tag">${r.employee_id}</span></td>
                        <td><b>${r.employee_name}</b></td>
                        <td>${r.date}</td>
                        <td>${r.raw_status}</td>
                    </tr>
                `).join('');
            }

            const ausBody = document.querySelector('#empAusenciasTable tbody');
            if (data.ausencias.length === 0) {
                ausBody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:#888;">Sin registros.</td></tr>`;
            } else {
                ausBody.innerHTML = data.ausencias.map(a => `
                    <tr>
                        <td><span class="tag">${a.employee_id}</span></td>
                        <td><b>${a.employee_name}</b></td>
                        <td>${a.date}</td>
                        <td>${a.raw_status}</td>
                    </tr>
                `).join('');
            }
        }

        function renderSapfMonthly(data) {
            const container = document.getElementById('sapfAreasContainer');
            if (data.data.length === 0) {
                container.innerHTML = `<p style="text-align:center; color:#888;">No hay fichas de atención en este rango.</p>`;
                return;
            }

            container.innerHTML = data.data.map(areaObj => `
                <div style="background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px; border: 1px solid #444;">
                    <h4 style="margin-top:0; color: var(--info); border-bottom: 1px solid #555; padding-bottom: 8px;">Área: ${areaObj.area} <span style="float:right; color:#fff; background:#333; padding:2px 8px; border-radius:12px; font-size:12px;">Total: ${areaObj.total_conteo}</span></h4>
                    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:10px;">
                        ${areaObj.monthly_data.map(m => `
                            <div style="background:#1e1e2f; padding:10px; border-radius:6px; min-width:80px; text-align:center; border: 1px solid #333;">
                                <div style="font-size:12px; color:#aaa;">${m.period}</div>
                                <div style="font-size:18px; font-weight:bold; color:var(--success);">${m.conteo}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `).join('');
        }

        function renderSapfMotivos(data) {
            const tBody = document.querySelector('#sapfMotivosTable tbody');
            if (data.motivos.length === 0) {
                tBody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#888;">No hay motivos registrados en este rango.</td></tr>`;
                return;
            }

            tBody.innerHTML = data.motivos.map(m => `
                <tr>
                    <td><span class="tag tag-warn">${m.area}</span></td>
                    <td><b>${m.motivo}</b></td>
                    <td style="color:var(--accent); font-weight:bold; font-size:16px;">${m.conteo}</td>
                </tr>
            `).join('');
        }

        function renderAcademicObs(data) {
            document.getElementById('obsKpiContainer').innerHTML = `
                <div class="kpi-box"><div class="val" style="color:var(--info);">${data.summary.total_observaciones}</div><div class="lbl">Total Realizadas</div></div>
                <div class="kpi-box"><div class="val" style="color:var(--success);">${data.summary.observaciones_con_comentarios}</div><div class="lbl">Con Estrategia Documentada</div></div>
            `;

            const dates = data.daily_trend.map(d => d.date);
            const totals = data.daily_trend.map(d => d.total);
            const withComments = data.daily_trend.map(d => d.with_comments);

            const ctx = document.getElementById('obsBarChart').getContext('2d');
            charts.obsBar = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: dates,
                    datasets: [
                        { label: 'Total Observaciones', data: totals, backgroundColor: '#3498db' },
                        { label: 'Con Estrategia', data: withComments, backgroundColor: '#2ecc71' }
                    ]
                },
                options: { responsive: true, maintainAspectRatio: false, scales: { y: { grid: { color: '#444' }, ticks: { color: '#ccc'} }, x: { grid: { display: false }, ticks: { color: '#ccc'} } }, plugins: { legend: { labels: { color: '#fff' } } } }
            });

            const tbody = document.querySelector('#obsCommentsTable tbody');
            if (data.feedback_list.length === 0) {
                tbody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#888;">No hay comentarios registrados en este rango.</td></tr>`;
            } else {
                tbody.innerHTML = data.feedback_list.map(f => `
                    <tr>
                        <td style="white-space: nowrap;"><span class="tag">${f.docente}</span></td>
                        <td style="white-space: nowrap; color:#aaa;">${f.date}</td>
                        <td>${f.comment}</td>
                    </tr>
                `).join('');
            }
        }

        function renderAcademicPlan(data) {
            document.getElementById('planKpiContainer').innerHTML = `
                <div class="kpi-box"><div class="val" style="color:var(--info);">${data.summary.total_planeaciones}</div><div class="lbl">Total Recibidas</div></div>
                <div class="kpi-box"><div class="val" style="color:var(--success);">${data.summary.planeaciones_con_feedback}</div><div class="lbl">Retroalimentadas</div></div>
            `;

            const dates = data.daily_trend.map(d => d.date);
            const totals = data.daily_trend.map(d => d.total);
            const withFeedback = data.daily_trend.map(d => d.with_feedback);

            const ctx = document.getElementById('planBarChart').getContext('2d');
            charts.planBar = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: dates,
                    datasets: [
                        { label: 'Total Recibidas', data: totals, backgroundColor: '#9b59b6' },
                        { label: 'Con Retroalimentación', data: withFeedback, backgroundColor: '#f1c40f' }
                    ]
                },
                options: { responsive: true, maintainAspectRatio: false, scales: { y: { grid: { color: '#444' }, ticks: { color: '#ccc'} }, x: { grid: { display: false }, ticks: { color: '#ccc'} } }, plugins: { legend: { labels: { color: '#fff' } } } }
            });

            const tbody = document.querySelector('#planCommentsTable tbody');
            if (data.feedback_list.length === 0) {
                tbody.innerHTML = `<tr><td colspan="3" style="text-align:center; color:#888;">No hay retroalimentación registrada en este rango.</td></tr>`;
            } else {
                tbody.innerHTML = data.feedback_list.map(f => `
                    <tr>
                        <td style="white-space: nowrap;"><span class="tag tag-warn">${f.docente}</span></td>
                        <td style="white-space: nowrap; color:#aaa;">${f.date}</td>
                        <td>${f.comment}</td>
                    </tr>
                `).join('');
            }
        }
    </script>
</body>
</html>
"""