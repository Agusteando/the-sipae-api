Recalibrate CEO compliance scoring and replace row-level tables with aggregate executive insights
